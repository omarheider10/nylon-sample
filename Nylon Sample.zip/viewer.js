import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {DRACOLoader} from 'three/addons/loaders/DRACOLoader.js';
import {RectAreaLightUniformsLib} from 'three/addons/lights/RectAreaLightUniformsLib.js';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {GTAOPass} from 'three/addons/postprocessing/GTAOPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';

const host=document.querySelector('#cable');
const status=document.querySelector('#status');
const views={
  whole:{target:[.8,0,0],orbit:[24.5,68,18.4]},
  detail:{target:[0,.25,.92],orbit:[25.7,57.9,2.12]},
  cutends:{target:[5.85,.12,.3],orbit:[23.9,61.5,3.66]}
};

try {
  RectAreaLightUniformsLib.init();
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.25));
  renderer.setClearColor(0,0);
  renderer.outputColorSpace=THREE.SRGBColorSpace;
  renderer.toneMapping=THREE.NeutralToneMapping;
  renderer.toneMappingExposure=1;
  renderer.domElement.tabIndex=0;
  renderer.domElement.setAttribute('aria-label','Blue braided cable. Drag to rotate, scroll or pinch to zoom.');
  host.appendChild(renderer.domElement);
  const scene=new THREE.Scene();
  scene.environment=null;
  const camera=new THREE.PerspectiveCamera(30,1,.005,200);
  const controls=new OrbitControls(camera,renderer.domElement);
  controls.enableDamping=true;
  controls.dampingFactor=.15;
  controls.rotateSpeed=.65;
  controls.zoomSpeed=.8;
  controls.panSpeed=.5;
  controls.minDistance=.25;
  controls.maxDistance=36;
  controls.listenToKeyEvents(renderer.domElement);
  const targetBuffer=new THREE.Vector3();
  const positionBuffer=new THREE.Vector3();
  function pose(view) {
    const [theta,phi,radius]=view.orbit;
    targetBuffer.fromArray(view.target);
    positionBuffer.setFromSphericalCoords(radius,THREE.MathUtils.degToRad(phi),THREE.MathUtils.degToRad(theta)).add(targetBuffer);
  }
  pose(views.whole);camera.position.copy(positionBuffer);controls.target.copy(targetBuffer);controls.update();

  const target=new THREE.WebGLRenderTarget(1,1,{type:THREE.HalfFloatType,samples:2});
  const composer=new EffectComposer(renderer,target);
  composer.addPass(new RenderPass(scene,camera));
  const gtao=new GTAOPass(scene,camera,1,1,undefined,{radius:.08,thickness:.05,distanceExponent:1,scale:1,samples:8},{lumaPhi:10,depthPhi:2,normalPhi:3,radius:3});
  gtao.blendIntensity=.55;
  composer.addPass(gtao);
  composer.addPass(new OutputPass());
  let pending=false,transition=null,previous=0;
  function requestFrame(){if(!pending){pending=true;requestAnimationFrame(render);}}
  function render(time) {
    pending=false;
    const dt=Math.min((time-previous)/1000,.05);previous=time;
    let moving=false;
    if(transition){
      const amount=1-Math.exp(-Math.max(dt,.016)/.08);
      controls.target.lerp(transition.target,amount);camera.position.lerp(transition.position,amount);
      if(camera.position.distanceToSquared(transition.position)<1e-7&&controls.target.distanceToSquared(transition.target)<1e-7){camera.position.copy(transition.position);controls.target.copy(transition.target);transition=null;}
      else moving=true;
    }
    moving=controls.update()||moving;
    composer.render();
    if(moving)requestFrame();
  }
  controls.addEventListener('change',requestFrame);
  controls.addEventListener('start',()=>{transition=null;requestFrame();});
  controls.addEventListener('end',requestFrame);
  for(const id of Object.keys(views))document.querySelector('#'+id).onclick=()=>{
    pose(views[id]);transition={target:targetBuffer.clone(),position:positionBuffer.clone()};previous=performance.now();requestFrame();
  };
  function resize(){
    const width=host.clientWidth,height=host.clientHeight;
    camera.aspect=width/height;camera.updateProjectionMatrix();renderer.setSize(width,height,false);composer.setSize(width,height);requestFrame();
  }
  new ResizeObserver(resize).observe(host);resize();
  const config=await fetch('./area-light-rig.json').then(r=>{if(!r.ok)throw new Error('Light rig failed to load');return r.json();});
  for(const settings of config.lights){
    const color=new THREE.Color().setRGB(...settings.color_linear_rgb,THREE.LinearSRGBColorSpace);
    const light=new THREE.RectAreaLight(color,settings.intensity,settings.width,settings.height);
    light.name=settings.name;light.position.fromArray(settings.position);light.quaternion.fromArray(settings.quaternion);scene.add(light);
  }
  renderer.toneMappingExposure=config.fixed_exposure;
  gtao.blendIntensity=config.web_contact_shadows.blend_intensity;
  gtao.updateGtaoMaterial({radius:config.web_contact_shadows.radius,thickness:config.web_contact_shadows.thickness});
  host.dataset.lighting='area-lights';host.dataset.areaLightCount=String(config.lights.length);host.dataset.environmentMap='none';host.dataset.exposure=String(config.fixed_exposure);
  const draco=new DRACOLoader().setDecoderPath('./vendor/draco/').setWorkerLimit(2);
  const loader=new GLTFLoader().setDRACOLoader(draco);
  const gltf=await loader.loadAsync('./Nylon%20Sample.glb?v=8ef93b8e6007');
  scene.add(gltf.scene);
  document.documentElement.dataset.modelLoaded='true';status.textContent='';status.hidden=true;
  requestFrame();
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)requestFrame();});
} catch(error) {
  console.error(error);
  status.hidden=false;status.textContent='The model could not load. Please reload the page.';
  document.documentElement.dataset.modelLoaded='false';
}
